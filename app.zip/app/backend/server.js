const express = require('express');
const path = require('path');
const cors = require('cors');
const mysql = require('mysql2/promise');
const neo4j = require('neo4j-driver');


const driver = neo4j.driver(
  'bolt://localhost:7687', 
  neo4j.auth.basic('neo4j', '123456789'),

);


const session = driver.session();

const {
  createUser,
  findUserByEmail,
  addSession,
  getModerators,
  getAllSessions,
  updateSession,
  deleteSession, 
  getAllUsers,    
  deleteUser,
  getExperts
} = require('./accountcontroller');

const app = express();
const PORT = process.env.PORT || 3000;


const pool = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: '123456789',
  database: 'rezcon',
  connectionLimit: 10 
});

app.use(express.json());
app.use(cors());


const getSessionsByExpertId = async (expert_id) => {
    const [sessions] = await pool.query(`
        SELECT s.* FROM sessions s
        JOIN session_experts se ON s.id = se.session_id
        WHERE se.expert_id = ?`, [expert_id]);
    return sessions;
};

app.post('/api/save-session-experts', async (req, res) => {
    const { sessionId, experts, criteria, weight } = req.body; // Destructure criteria and weight from the request body

    // SQL query to insert data into session_experts
    const sql = 'INSERT INTO session_experts (session_id, expert_id, ref, critere, ponderation) VALUES ?';

    // Map over experts to create an array of values, including criteria and weight
    const values = experts.map(expert => [
        sessionId,      // session_id
        expert.id,     // expert_id
        expert.index,  // ref
        criteria,      // critere
        weight          // ponderation
    ]);

    try {
        // Execute the query with the array of values
        const [results] = await pool.query(sql, [values]);
        res.send('Data saved successfully');
    } catch (error) {
        console.error('Error inserting data:', error);
        res.status(500).send('Error saving data');
    }
});

app.patch('/api/update-session-progress/:id', async (req, res) => {
    const { id } = req.params;
    const { status } = req.body; // Changement ici pour utiliser "status"

    // Vérification si le status est fourni
    if (status === undefined) {
        return res.status(400).json({ message: 'Le statut est requis' }); // Changement ici pour "statut"
    }

    try {
        // Met à jour le statut de la session dans la table MySQL
        const result = await pool.query(
            'UPDATE sessions SET status = ? WHERE id = ?', // Changement ici pour "status"
            [status, id]
        );

        // Vérifie si la session a été trouvée et mise à jour
        if (result[0].affectedRows === 0) {
            return res.status(404).json({ message: 'Session non trouvée' });
        }

        res.status(200).json({ message: 'Statut de la session mis à jour' }); // Changement ici pour "statut"
    } catch (error) {
        console.error('Erreur lors de la mise à jour du statut de la session:', error); // Changement ici pour "statut"
        res.status(500).json({ message: 'Erreur lors de la mise à jour du statut de la session' }); // Changement ici pour "statut"
    }
});



app.post('/api/register', async (req, res) => {
    const { email, password, role, name, lastname, phone } = req.body;

    try {
        if (!email || !password || !role || !name || !lastname || !phone) {
            return res.status(400).json({ message: 'All fields are required' });
        }

        const existingUser = await findUserByEmail(email);
        if (existingUser) {
            return res.status(400).json({ message: 'Email already registered' });
        }

        const newUser = await createUser(email, password, role, name, lastname, phone);
        res.status(201).json(newUser);
    } catch (error) {
        console.error('Error creating user:', error);
        res.status(500).json({ message: 'Error creating user' });
    }
});

app.post('/api/login', async (req, res) => {
    const { email, password } = req.body;

    try {
        const user = await findUserByEmail(email);
        if (!user) {
            return res.status(400).json({ message: 'User not found' });
        }

        if (password !== user.password) {
            return res.status(400).json({ message: 'Invalid credentials' });
        }

        res.status(200).json({ message: 'Login successful', user });
    } catch (error) {
        console.error('Error logging in:', error);
        res.status(500).json({ message: 'Error logging in' });
    }
});

app.post('/api/sessions', async (req, res) => {
    const { description, nom, start, end, moderator, status } = req.body;
    
    console.log('Received data:', { description, nom, start, end, moderator, status });

    try {
        if (!description || !nom || !start || !end || !status) {
            return res.status(400).json({ message: 'All fields are required' });
        }

        const newSession = await addSession(description, nom, start, end, moderator, status);
        res.status(201).json(newSession);
    } catch (error) {
        console.error('Error creating session:', error);
        res.status(500).json({ message: 'Error creating session' });
    }
});

app.get('/api/moderators', async (req, res) => {
    try {
        const moderators = await getModerators();
        res.status(200).json(moderators);
    } catch (error) {
        console.error('Error fetching moderators:', error);
        res.status(500).json({ message: 'Error fetching moderators' });
    }
});

app.get('/api/sessions', async (req, res) => {
    const { moderator_id } = req.query;

    try {
        let sessions;
        if (moderator_id) {
            sessions = await getAllSessions(moderator_id);
        } else {
            sessions = await getAllSessions();
        }
        res.status(200).json(sessions);
    } catch (error) {
        console.error('Error fetching sessions:', error);
        res.status(500).json({ message: 'Error fetching sessions' });
    }
});

app.put('/api/sessions/:id', async (req, res) => {
    const { id } = req.params;
    const { description, nom, start, end, moderator, status } = req.body;

    if (!description || !nom || !start || !end || !status) {
        return res.status(400).json({ message: 'All fields are required' });
    }

    try {
        await updateSession(id, description, nom, start, end, moderator, status);
        res.status(200).json({ message: 'Session updated successfully' });
    } catch (error) {
        console.error('Error updating session:', error);
        res.status(500).json({ message: `Error updating session: ${error.message}` });
    }
});

app.delete('/api/sessions/:id', async (req, res) => {
    const { id } = req.params;

    try {
        await deleteSession(id);
        res.status(200).json({ message: 'Session deleted successfully' });
    } catch (error) {
        console.error('Error deleting session:', error);
        res.status(500).json({ message: 'Error deleting session' });
    }
});

app.get('/api/users', async (req, res) => {
    try {
        const users = await getAllUsers();
        res.status(200).json(users);
    } catch (error) {
        console.error('Error fetching users:', error);
        res.status(500).json({ message: 'Error fetching users' });
    }
});

app.delete('/api/users/:id', async (req, res) => {
    const { id } = req.params;

    try {
        await deleteUser(id);
        res.status(200).json({ message: 'User deleted successfully' });
    } catch (error) {
        console.error('Error deleting user:', error);
        res.status(500).json({ message: 'Error deleting user' });
    }
});

app.get('/api/experts', async (req, res) => {
    try {
        const experts = await getExperts();
        res.status(200).json(experts);
    } catch (error) {
        console.error('Error fetching experts:', error.message);
        res.status(500).json({ message: 'Error fetching experts' });
    }
});

app.post('/api/competences', async (req, res) => {
    const { competence, resourceReference } = req.body;

    try {
        const result = await session.run(
            'MERGE (c:Competence {nom: $competence}) ' +
            'MERGE (r:Resource {reference: $resourceReference}) ' +
            'CREATE (r)-[:VISE]->(c)',
            { competence, resourceReference }
        );

        res.status(200).json({ message: 'Compétence ajoutée avec succès' });
    } catch (error) {
        console.error('Erreur avec Neo4j:', error);
        res.status(500).json({ message: 'Erreur lors de l\'ajout de la compétence' });
    }
});
app.delete('/api/competences', async (req, res) => {
    const { competence } = req.body;

    try {
        const result = await session.run(
            'MATCH (c:Competence {nom: $competence}) DETACH DELETE c',
            { competence }
        );

        res.status(200).json({ message: 'Compétence supprimée avec succès' });
    } catch (error) {
        console.error('Erreur avec Neo4j:', error);
        res.status(500).json({ message: 'Erreur lors de la suppression de la compétence' });
    }
});
app.get('/api/competences', async (req, res) => {
    try {
        const result = await session.run(
            'MATCH (c:Competence) RETURN c.nom AS nom'
        );

        const competences = result.records.map(record => record.get('nom'));
        res.status(200).json(competences);
    } catch (error) {
        console.error('Erreur avec Neo4j:', error);
        res.status(500).json({ message: 'Erreur lors de la récupération des compétences' });
    }
});
app.post('/api/ressources', async (req, res) => {
    const { reference, description } = req.body;

    try {
        const result = await session.run(
            'MERGE (r:Resource {reference: $reference, description: $description})',
            { reference, description }
        );

        res.status(200).json({ message: 'Ressource ajoutée avec succès' });
    } catch (error) {
        console.error('Erreur avec Neo4j:', error);
        res.status(500).json({ message: 'Erreur lors de l\'ajout de la ressource' });
    }
});
app.get('/api/ressources', async (req, res) => {
    try {
        // Running a Cypher query to fetch resources from Neo4j
        const result = await session.run(
            'MATCH (r:Resource) RETURN r.reference AS reference, r.description AS description'
        );

        // Mapping the result into a more readable format
        const ressources = result.records.map(record => ({
            reference: record.get('reference'),
            description: record.get('description')
        }));

        // If successful, return the resources in JSON format
        res.status(200).json(ressources);
    } catch (error) {
        // Logging the detailed error message and stack for debugging
        console.error('Erreur avec Neo4j:', error.message, error.stack);

        // Sending a 500 error response to the client with a clear message
        res.status(500).json({ message: 'Erreur lors de la récupération des ressources' });
    }
});


app.delete('/api/ressources', async (req, res) => {
    const { reference } = req.body;

    try {
        const result = await session.run(
            'MATCH (r:Resource {reference: $reference}) DETACH DELETE r',
            { reference }
        );

        if (result.summary.counters.nodesDeleted === 0) {
            return res.status(404).json({ message: 'Ressource non trouvée' });
        }

        res.status(200).json({ message: 'Ressource supprimée avec succès' });
    } catch (error) {
        console.error('Erreur avec Neo4j:', error);
        res.status(500).json({ message: 'Erreur lors de la suppression de la ressource' });
    }
});







app.use(express.static(path.join(__dirname, '../rezcon-app/dist')));

app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '../rezcon-app/dist/index.html'));
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
