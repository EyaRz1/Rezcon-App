import './ModerateurSuiv.css';
import { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import axios from 'axios';
import PropTypes from 'prop-types';
const ModerateurSuiv = ({ createUser }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const { name = '', lastname = '', email = '', phone = '' } = location.state || {};
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [errors, setErrors] = useState({});

  const validateForm = () => {
    const errors = {};
    if (!password) errors.password = "Le mot de passe est requis";
    if (password !== confirmPassword) errors.confirmPassword = "Les mots de passe ne correspondent pas";
    return errors;
  };

  const handleCreateAccount = async () => {
    const errors = validateForm();
    setErrors(errors);

    if (Object.keys(errors).length === 0) {
      const newUser = {
        name,
        lastname,
        email,
        phone,
        password,
        role: 'moderateur',
      };

      try {
        const response = await axios.post('/api/register', newUser);
        createUser(response.data); 
        navigate('/moderateurDashboard', { state: { user: response.data } }); 
      } catch (err) {
        setErrors({ general: err.response?.data?.message || 'Error creating account' });
      }
    }
  };

  return (
    <div className="moderateursuiv-container">
      <div className="moderateursuiv-box">
        <h2>Créez votre compte modérateur!</h2>
        <div className="contentsuiv">
          <div className="moderateursuiv-form">
            <div className="formsuiv-row">
              <div className="formsuiv-group">
                <label htmlFor="mdp">Mot de passe</label>
                <input 
                  type="password" 
                  id="mdp" 
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
                {errors.password && <p className="error">{errors.password}</p>}
              </div>
              <div className="formsuiv-group">
                <label htmlFor="cmdp">Confirmez votre mot de passe</label>
                <input 
                  type="password" 
                  id="cmdp" 
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                />
                {errors.confirmPassword && <p className="error">{errors.confirmPassword}</p>}
              </div>
            </div>
            {errors.general && <p className="error">{errors.general}</p>}
            <button className="suivantsuiv-btn" onClick={handleCreateAccount}>Créer un compte</button>
          </div>
        </div>
      </div>
    </div>
  );
};
ModerateurSuiv.propTypes = {
  createUser: PropTypes.func.isRequired,
};
export default ModerateurSuiv;
