import { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import axios from 'axios';
import './ConnecterSess.css';

function ConnecterSess({ onClose, userId }) {
  const [sessions, setSessions] = useState([]);

  useEffect(() => {
    console.log('userId in useEffect:', userId);
    const fetchSessions = async () => {
      try {
        const response = await axios.get(`/api/sessions?moderator_id=${userId}`);
        console.log('Fetched sessions:', response.data);
        setSessions(response.data);
      } catch (error) {
        console.error('Error fetching sessions:', error);
      }
    };

    if (userId) {  // Only fetch if userId is available
      fetchSessions();
    }
  }, [userId]);

  const handleConnect = (sessionId) => {
    console.log(`Connecting to session ID: ${sessionId}`);
    // Here you can add the logic to actually connect to the session
    // For example, redirecting to a session detail page, or opening a session
  };

  return (
    <div className="consulter-sess-overlay">
      <div className="consulter-sess-container">
        <div className="consulter-sess-header">
          <h1>Consulter Sessions</h1>
          <button className="close-button" onClick={onClose}>&times;</button>
        </div>
        <div className="consulter-sess-content">
          <ul>
            {sessions.map(session => (
              <li key={session.id} className="session-item">
                <p><strong>ID:</strong> {session.id}</p>
                <p><strong>Nom:</strong> {session.nom}</p>
                <p><strong>Description:</strong> {session.description}</p>
                <p><strong>Démarrage:</strong> {new Date(session.start).toLocaleDateString()}</p>
                <p><strong>Fin:</strong> {new Date(session.end).toLocaleDateString()}</p>
                <p><strong>Modérateur:</strong> {session.moderator}</p>
                <p><strong>Status:</strong> {session.status}</p>
                <button className="connect-button" onClick={() => handleConnect(session.id)}>Se connecter</button>
              </li>
            ))}
          </ul>
        </div>
        <div className="consulter-sess-footer">
          <button className="cancel-button" onClick={onClose}>Fermer</button>
        </div>
      </div>
    </div>
  );
}

ConnecterSess.propTypes = {
  onClose: PropTypes.func.isRequired,
  userId: PropTypes.number.isRequired, 
};

export default ConnecterSess;
