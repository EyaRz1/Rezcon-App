
import { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import axios from 'axios';
import './ConsulterUsers.css'; 

const ConsulterUsers = ({ onClose }) => {
    const [users, setUsers] = useState([]);

    useEffect(() => {
        const fetchUsers = async () => {
            try {
                const response = await axios.get('/api/users');
                setUsers(response.data);
            } catch (error) {
                console.error('Error fetching users:', error);
            }
        };

        fetchUsers();
    }, []);

    return (
        <div className="consulter-users-overlay">
            <div className="consulter-users-container">
                <div className="consulter-users-header">
                    <h2>Consulter les Utilisateurs</h2>
                    <button className="close-button" onClick={onClose}>X</button>
                </div>
                <div className="consulter-users-content">
                    {users.length === 0 ? (
                        <p>Aucun utilisateur trouvé.</p>
                    ) : (
                        <table className="users-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Nom</th>
                                    <th>Email</th>
                                    <th>Rôle</th>
                                </tr>
                            </thead>
                            <tbody>
                                {users.map(user => (
                                    <tr key={user.id}>
                                        <td>{user.id}</td>
                                        <td>{user.name}</td>
                                        <td>{user.email}</td>
                                        <td>{user.role}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    )}
                </div>
                <div className="consulter-users-footer">
                    <button className="cancel-button" onClick={onClose}>Annuler</button>
                </div>
            </div>
        </div>
    );
};

ConsulterUsers.propTypes = {
    onClose: PropTypes.func.isRequired,
};

export default ConsulterUsers;
