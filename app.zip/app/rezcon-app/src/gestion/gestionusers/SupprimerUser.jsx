import { useState } from 'react';
import axios from 'axios';
import './supprimerUser.css';
import PropTypes from 'prop-types';

function SupprimerUser({ onClose }) {
    const [userId, setUserId] = useState('');
    const [message, setMessage] = useState('');

    const handleDelete = async () => {
        try {
            await axios.delete(`/api/users/${userId}`);
            setMessage('Utilisateur supprimé avec succès');
            onClose();
        } catch (error) {
            console.error('Error deleting user:', error);
            setMessage('Erreur lors de la suppression de l’utilisateur');
        }
    };

    return (
        <div className="modal-overlay">
            <div className="modal-container">
                <h2>Supprimer Utilisateur</h2>
                <input
                    type="text"
                    value={userId}
                    onChange={(e) => setUserId(e.target.value)}
                    placeholder="Entrez l'ID de l'utilisateur"
                />
                <button onClick={handleDelete} className="action-button">Supprimer</button>
                <button onClick={onClose} className="cancel-button">Annuler</button>
                {message && <p>{message}</p>}
            </div>
        </div>
    );
}
SupprimerUser.propTypes = {
    onClose: PropTypes.func.isRequired,
};

export default SupprimerUser;
