import './Adminsuiv.css';
import { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import axios from 'axios';
import PropTypes from 'prop-types';

const AdminSuiv = ({ createUser }) => {
    const navigate = useNavigate();
    const location = useLocation();
    const { name = '', lastname = '', email = '', phone = '' } = location.state || {};
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [error, setError] = useState('');

    const handleCreateAccount = async () => {
        if (!password || !confirmPassword) {
            setError('Password fields must be filled out');
            return;
        }

        if (password !== confirmPassword) {
            setError('Passwords do not match');
            return;
        }

        const newUser = {
            name,
            lastname, 
            email,
            phone,
            password,
            role: 'admin',
        };
        console.log('Form data being sent:', newUser);

        try {
            const response = await axios.post('/api/register', newUser);
            createUser(response.data); 
            navigate('/dashboard', { state: { user: response.data } }); 
        } catch (err) {
            setError(err.response?.data?.message || 'Error creating account');
        }
    };

    return (
        <div className="adminsuiv-container">
            <div className="adminsuiv-box">
                <h2>Rejoignez-nous et optimisez vos évaluations!</h2>
                <div className="contentsuiv">
                    <div className="adminsuiv-form">
                        <div className="formsuiv-row">
                            <div className="formsuiv-group">
                                <label htmlFor="mdp">Mot de passe</label>
                                <input 
                                    type="password" 
                                    id="mdp" 
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                />
                            </div>
                            <div className="formsuiv-group">
                                <label htmlFor="cmdp">Confirmez votre mot de passe</label>
                                <input 
                                    type="password" 
                                    id="cmdp" 
                                    value={confirmPassword}
                                    onChange={(e) => setConfirmPassword(e.target.value)}
                                />
                            </div>
                        </div>
                        {error && <p className="error-message">{error}</p>}
                        <button className="suivantsuiv-btn" onClick={handleCreateAccount}>Créer un compte</button>
                    </div>
                </div>
            </div>
        </div>
    );
};

AdminSuiv.propTypes = {
    createUser: PropTypes.func.isRequired,
};

export default AdminSuiv;
