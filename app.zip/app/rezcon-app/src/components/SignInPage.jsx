import { useState } from 'react';
import './SignInPage.css';
import { useNavigate } from 'react-router-dom';
import PropTypes from 'prop-types';

const SignInPage = ({ authenticateUser }) => {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleLoginClick = async () => {
    try {
      const response = await authenticateUser(email, password);
      if (response && response.user) {
        const { role } = response.user;
        const dashboardRoute = role === 'admin' ? '/Dashboard' : `/${role}Dashboard`;
        navigate(dashboardRoute, { state: { user: response.user } });
      } else {
        alert('Invalid credentials');
      }
    } catch (error) {
      alert('Invalid credentials');
    }
  };

  const handleCreateAccountClick = (role) => {
    switch(role) {
      case 'admin':
        navigate('/admin');
        break;
      case 'moderateur':
        navigate('/moderateur');
        break;
      case 'expert':
        navigate('/expert');
        break;
      default:
        navigate('/signin'); // Fallback in case role is not recognized
    }
  };
  

  return (
    <div className="sign-in-container">
      <div className="sign-in-box">
        
        <h2>Unlimited free access to our resources</h2>
        <div className="content-sn">
          <div className="account-types">
            <h4>Créer un compte pour</h4>
         
            <button className="account-btn" onClick={() => handleCreateAccountClick('moderateur')}>modérateur</button>
            <button className="account-btn" onClick={() => handleCreateAccountClick('expert')}>expert</button>
           
          </div>
          <div className="sign-in-form">
            <h4>se connecter</h4>
            <input 
              type="text" 
              placeholder="Adresse Email/ id" 
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
            <input 
              type="password" 
              placeholder="Mot de Passe" 
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          
            <button className="sign-in-btn" onClick={handleLoginClick}>Log in</button>
          </div>
        </div>
        <footer>
          <div className="footer-language">
            <select>
              <option>Français (France)</option>
            </select>
          </div>
          <div className="footer-links">
            <a href="#">About</a>
            <a href="#">Help Center</a>
            <a href="#">Terms of Service</a>
            <a href="#">Privacy Policy</a>
            <a href="#">Cookie Policy</a>
          </div>
        </footer>
      </div>
    </div>
  );
};

SignInPage.propTypes = {
  authenticateUser: PropTypes.func.isRequired,
};

export default SignInPage;
