import { useState } from 'react';
import axios from 'axios';
import './SupprimerComp.css'; 
import PropTypes from 'prop-types'; 

const SupprimerComp = ({ onClose }) => {
    const [competence, setCompetence] = useState('');

    const handleDelete = async () => {
        try {
            const response = await axios.delete('/api/competences', {
                data: { competence }
            });
            alert(response.data.message);
        } catch (error) {
            console.error('Erreur lors de la suppression de la compétence:', error);
            alert('Erreur lors de la suppression de la compétence');
        }
    };

    return (
        <div className="modal-overlay">
            <div className="modal-content">
                <button className="close-btn" onClick={onClose}>X</button>
                <h2>Supprimer Compétence</h2>
                <input 
                    type="text" 
                    value={competence}
                    onChange={(e) => setCompetence(e.target.value)} 
                    placeholder="Nom de la compétence" 
                />
                <div className="button-group">
                    <button onClick={handleDelete}>Supprimer</button>
                    <button className="cancel-btn" onClick={onClose}>Annuler</button>
                </div>
            </div>
        </div>
    );
};

SupprimerComp.propTypes = {
    onClose: PropTypes.func.isRequired,
};

export default SupprimerComp;
