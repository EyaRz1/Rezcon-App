import { useNavigate } from 'react-router-dom';
import './HomePage.css'; 
import logo2 from './logo-2.png'; // Import logo-2

const HomePage = () => {
  const navigate = useNavigate();

  const handleLoginClick = () => {
    navigate('/signin'); 
  };

  return (
    <div className="home-container">
      {/* Add the logo-2 here and use CSS to position it in the top-right corner */}
      <img src={logo2} alt="Logo 2" className="logo-2" />
      <nav className="navbar">
        <a href="/">Home</a>
        <a href="/about">About us</a>
      </nav>
      <div className="hero-section">
        <h1>REZCON</h1>
        <p>Simplifiez la gestion des avis et des évaluations</p>
        <div className="buttons">
          <button className="start-btn" onClick={handleLoginClick}>commencer</button>
          <button className="login-btn" onClick={handleLoginClick}>Se connecter</button>
        </div>
      </div>
      <div className="features">
        <div className="feature">
          <i className="fas fa-heart"></i>
          <p>Rejoignez-nous dès aujourdhui et optimisez vos évaluations!</p>
        </div>
        <div className="feature">
          <i className="fas fa-star"></i>
          <p>-Gestion des évaluations simplifiée<br/>-Fusion intelligente des résultats</p>
        </div>
        <div className="feature">
          <i className="fas fa-eye"></i>
          <p>Email : support@rezcon.com<br/>Téléphone : +216 1 23 45 67 8</p>
        </div>
      </div>
    </div>
  );
};

export default HomePage;
