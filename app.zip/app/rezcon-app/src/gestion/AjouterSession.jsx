import { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import './AjouterSession.css'; 
import axios from 'axios';

const AjouterSession = ({ onClose }) => {
    const [moderators, setModerators] = useState([]);
    const [formData, setFormData] = useState({
        description: '',
        nom: '',
        start: '',
        end: '',
        moderator: '',
        status: 'Planifié',
    });

    useEffect(() => {
        const fetchModerators = async () => {
            try {
                const response = await axios.get('/api/moderators');
                setModerators(response.data);
            } catch (error) {
                console.error('Error fetching moderators:', error);
            }
        };
        fetchModerators();
    }, []);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prevData => ({
            ...prevData,
            [name]: value
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await axios.post('/api/sessions', formData);
            alert('Session ajoutée avec succès!');
            onClose();
        } catch (error) {
            console.error('Error adding session:', error);
        }
    };

    return (
        <div className="ajouter-session-overlay">
            <div className="ajouter-session-container">
                <div className="ajouter-session-header">
                    <h2>Ajouter une Session</h2>
                    <button className="close-button-ajout" onClick={onClose}>&times;</button>
                </div>
                <form onSubmit={handleSubmit}>
                    <div className="form-group">
                        <label>Description:</label>
                        <input 
                            type="text" 
                            name="description" 
                            value={formData.description} 
                            onChange={handleChange} 
                            required 
                        />
                    </div>
                    <div className="form-group">
                        <label>Nom:</label>
                        <input 
                            type="text" 
                            name="nom" 
                            value={formData.nom} 
                            onChange={handleChange} 
                            required 
                        />
                    </div>
                    <div className="form-group">
                        <label>Début:</label>
                        <input 
                            type="datetime-local" 
                            name="start" 
                            value={formData.start} 
                            onChange={handleChange} 
                            required 
                        />
                    </div>
                    <div className="form-group">
                        <label>Fin:</label>
                        <input 
                            type="datetime-local" 
                            name="end" 
                            value={formData.end} 
                            onChange={handleChange} 
                            required 
                        />
                    </div>
                    <div className="form-group">
                        <label>Modérateur:</label>
                        <select 
                            name="moderator" 
                            value={formData.moderator} 
                            onChange={handleChange} 
                            required
                        >
                            <option value="">Sélectionner un modérateur</option>
                            {moderators.map(mod => (
                                <option key={mod.id} value={mod.id}>
                                    {mod.name} {mod.lastname}
                                </option>
                            ))}
                        </select>
                    </div>
                    <div className="form-group">
                        <label>Status:</label>
                        <select 
                            name="status" 
                            value={formData.status} 
                            onChange={handleChange}
                        >
                            <option value="Planifié">Planifié</option>
                            <option value="En cours">En cours</option>
                            <option value="Terminé">Terminé</option>
                        </select>
                    </div>
                    <div className="ajouter-session-footer">
                        <button 
                            className="cancel-button-ajout" 
                            type="button" 
                            onClick={onClose}
                        >
                            Annuler
                        </button>
                        <button 
                            className="save-button-ajout" 
                            type="submit"
                        >
                            Enregistrer
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

AjouterSession.propTypes = {
    onClose: PropTypes.func.isRequired,
};

export default AjouterSession;
