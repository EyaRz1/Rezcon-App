import { useState } from 'react';
import axios from 'axios';
import './AjouterComp.css';
import PropTypes from 'prop-types'; 

const AjouterComp = ({ onClose }) => {
    const [competence, setCompetence] = useState('');
    const [resourceReference, setResourceReference] = useState('');

    const handleAdd = async () => {
        try {
            const response = await axios.post('/api/competences', {
                competence,
                resourceReference
            });
            alert(response.data.message);
        } catch (error) {
            console.error('Erreur lors de l\'ajout de la compétence:', error);
            alert('Erreur lors de l\'ajout de la compétence');
        }
    };

    return (
        <div className="modal-overlay">
            <div className="modal-content">
                <button className="close-btn" onClick={onClose}>X</button>
                <h2>Ajouter Compétence</h2>
                <input 
                    type="text" 
                    value={competence}
                    onChange={(e) => setCompetence(e.target.value)} 
                    placeholder="Nom de la compétence" 
                />
                <input 
                    type="text" 
                    value={resourceReference}
                    onChange={(e) => setResourceReference(e.target.value)} 
                    placeholder="Référence de la ressource" 
                />
                <div className="button-group">
                    <button onClick={handleAdd}>Ajouter</button>
                    <button className="cancel-btn" onClick={onClose}>Annuler</button>
                </div>
            </div>
        </div>
    );
};

AjouterComp.propTypes = {
    onClose: PropTypes.func.isRequired,
};

export default AjouterComp;
