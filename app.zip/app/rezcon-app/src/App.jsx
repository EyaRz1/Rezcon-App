import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { useState } from 'react';
import SignInPage from './components/SignInPage';
import Admin from './components/Admin';
import AdminSuiv from './components/AdminSuiv';
import HomePage from './components/Homepage';
import Dashboard from './components/Dashboard';
import Moderateur from './components/Moderateur';
import ModerateurSuiv from './components/Moderateursuiv';
import ModerateurDashboard from './components/ModerateurDashboard';
import ExpertDashboard from './components/ExpertDashboard';
import Expert from './components/Expert';
import ExpertSuiv from './components/ExpertSuiv';
import AjouterSession from './gestion/AjouterSession';
import GestionSess from './gestion/gestionSess';
import EditerSession from './gestion/EditerSession';
import ConsulterSess from './gestion/ConsulterSess'; 
import SupprimerSess from './gestion/SupprimerSess';
import ConsulterUsers from './gestion/gestionusers/ConsulterUsers';
import SupprimerUser from './gestion/gestionusers/SupprimerUser';
import GestionUsers from './gestion/gestionusers/GestionUsers';
import AjouterComp from './gestion/comp/AjouterComp';
import SupprimerComp from './gestion/comp/supprimerComp';
import ConsulterComp from './gestion/comp/ConsulterComp';
import axios from 'axios';

function App() {
  const [authenticatedUser, setAuthenticatedUser] = useState(null);
  const [users, setUsers] = useState([]);
  const [sessions, setSessions] = useState([]); 

  const evaluations = [
    { type: 'grille', deadline: '31/07/24', moderator: 'lief B.', experts: ['salah.m', 'Adam.f'], progress: 75 },
    { type: 'cours', deadline: '28/07/24', moderator: 'eya R.', experts: ['AHMED.j', 'narimen.l'], progress: 75 }
  ];

  const createUser = (newUser) => {
    setUsers([...users, newUser]);
    setAuthenticatedUser(newUser);
    console.log("User created:", newUser);
    console.log("Authenticated User after creation:", authenticatedUser);
  };

  const authenticateUser = async (email, password, role) => {
    try {
      const response = await axios.post('/api/login', { email, password, role });
      if (response.data.user) {
        setAuthenticatedUser(response.data.user);
        return response.data;
      } else {
        throw new Error('Invalid credentials');
      }
    } catch (error) {
      console.error('Login error:', error);
      throw error;
    }
  };

  const logoutUser = () => {
    setAuthenticatedUser(null);
  };

  return (
    <Router>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/signin" element={<SignInPage authenticateUser={authenticateUser} />} />
        <Route path="/admin" element={<Admin />} />
        <Route path="/adminsuiv" element={<AdminSuiv createUser={createUser} />} />
        <Route path="/dashboard" element={<Dashboard sessions={sessions} evaluations={evaluations} user={authenticatedUser} logoutUser={logoutUser} />} />
        <Route path="/moderateur" element={<Moderateur />} />
        <Route path="/moderateursuiv" element={<ModerateurSuiv createUser={createUser} />} />
        <Route path="/moderateurDashboard" element={<ModerateurDashboard sessions={sessions} evaluations={evaluations} user={authenticatedUser} logoutUser={logoutUser} />} />
        <Route path="/expertDashboard" element={<ExpertDashboard evaluations={evaluations} user={authenticatedUser} logoutUser={logoutUser} />} />
        <Route path="/expert" element={<Expert />} />
        <Route path="/expertsuiv" element={<ExpertSuiv createUser={createUser} />} />
        <Route path="/gestion-sess" element={<GestionSess setSessions={setSessions} />} /> 
        <Route path="/ajouter-session" element={<AjouterSession />} />
        <Route path="/editersession" element={<EditerSession />} />
        <Route path="/consulter-sess" element={<ConsulterSess sessions={sessions} />} /> 
        <Route path="/supprimer-sess" element={<SupprimerSess sessions={sessions} />} /> 
        <Route path="/gestion-users" element={<GestionUsers />} />
        <Route path="/consulter-users" element={<ConsulterUsers users={users} />} />
        <Route path="/supprimer-user" element={<SupprimerUser users={users} />} />
        <Route path="/ajouter-comp" element={<AjouterComp />} />
                <Route path="/supprimer-comp" element={<SupprimerComp />} />
                <Route path="/consulter-comp" element={<ConsulterComp />} />
      </Routes>
    </Router>
  );
}

export default App;
