import PropTypes from 'prop-types';
import { useState, useEffect } from 'react';
import axios from 'axios';
import './EditerSession.css';

const EditerSession = ({ onClose, sessions }) => {
    const [formData, setFormData] = useState({
        id: '',
        description: '',
        nom: '',
        start: '',
        end: '',
        moderator: '',
        status: ''
    });

    useEffect(() => {
        if (sessions.length > 0) {
            const session = sessions[0];
            setFormData({
                id: session.id,
                description: session.description,
                nom: session.nom,
                start: session.start,
                end: session.end,
                moderator: session.moderator || '',
                status: session.status
            });
        }
    }, [sessions]);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prevData => ({
            ...prevData,
            [name]: value
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        console.log('Submitting data:', formData);  
        try {
            await axios.put(`/api/sessions/${formData.id}`, formData);
            alert('Session mise à jour avec succès!');
            onClose();
        } catch (error) {
            console.error('Erreur lors de la mise à jour de la session:', error);
            alert('Erreur lors de la mise à jour de la session');
        }
    };

    const handleSelectSession = (e) => {
        const selectedId = e.target.value;
        const selectedSession = sessions.find(s => s.id === parseInt(selectedId));
        if (selectedSession) {
            setFormData({
                id: selectedSession.id,
                description: selectedSession.description,
                nom: selectedSession.nom,
                start: selectedSession.start,
                end: selectedSession.end,
                moderator: selectedSession.moderator || '',
                status: selectedSession.status
            });
        }
    };

    return (
        <div className="edit-session-overlay">
            <div className="edit-session-container">
                <div className="edit-session-header">
                    <h2>Éditer une Session</h2>
                    <button className="close-button" onClick={onClose}>&times;</button>
                </div>
                <div className="form-group">
                    <label>Sélectionnez une session à éditer :</label>
                    <select onChange={handleSelectSession} value={formData.id}>
                        <option value="">Sélectionner une session</option>
                        {sessions.map(sess => (
                            <option key={sess.id} value={sess.id}>
                                {sess.nom} - {sess.description}
                            </option>
                        ))}
                    </select>
                </div>
                {formData.id && (
                    <form onSubmit={handleSubmit}>
                        <div className="form-group">
                            <label>Nom :</label>
                            <input
                                type="text"
                                name="nom"
                                value={formData.nom}
                                onChange={handleChange}
                                required
                            />
                        </div>
                        <div className="form-group">
                            <label>Description :</label>
                            <input
                                type="text"
                                name="description"
                                value={formData.description}
                                onChange={handleChange}
                                required
                            />
                        </div>
                        <div className="form-group">
                            <label>Date de début :</label>
                            <input
                                type="date"
                                name="start"
                                value={formData.start}
                                onChange={handleChange}
                                required
                            />
                        </div>
                        <div className="form-group">
                            <label>Date de fin :</label>
                            <input
                                type="date"
                                name="end"
                                value={formData.end}
                                onChange={handleChange}
                                required
                            />
                        </div>
                        <div className="form-group">
                            <label>Modérateur :</label>
                            <input
                                type="text"
                                name="moderator"
                                value={formData.moderator}
                                onChange={handleChange}
                            />
                        </div>
                        <div className="form-group">
                            <label>Statut :</label>
                            <input
                                type="text"
                                name="status"
                                value={formData.status}
                                onChange={handleChange}
                                required
                            />
                        </div>
                        <button type="submit" className="submit-button">Mettre à jour</button>
                    </form>
                )}
            </div>
        </div>
    );
};

EditerSession.propTypes = {
    onClose: PropTypes.func.isRequired,
    sessions: PropTypes.arrayOf(PropTypes.shape({
        id: PropTypes.number.isRequired,
        description: PropTypes.string.isRequired,
        nom: PropTypes.string.isRequired,
        start: PropTypes.string.isRequired,
        end: PropTypes.string.isRequired,
        moderator: PropTypes.string,
        status: PropTypes.string.isRequired,
    })).isRequired,
};

export default EditerSession;
