import { useState, useEffect } from 'react';
import axios from 'axios';
import PropTypes from 'prop-types';

const SupprimerRess = ({ onClose }) => {
    const [resources, setResources] = useState([]);
    const [selectedResourceReference, setSelectedResourceReference] = useState('');
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchResources = async () => {
            try {
                const response = await axios.get('/api/ressources');
                setResources(response.data);
            } catch (error) {
                setError('Erreur lors de la récupération des ressources');
            }
        };

        fetchResources();
    }, []);

    const handleDelete = async () => {
        try {
            await axios.delete('/api/ressources', { 
                data: { reference: selectedResourceReference } 
            });
            setSelectedResourceReference('');
            onClose();
        } catch (error) {
            setError('Erreur lors de la suppression de la ressource');
        }
    };

    return (
        <div className="modal-overlay">
            <div className="modal-content">
                <button className="close-btn" onClick={onClose}>X</button>
                <h2>Supprimer une Ressource</h2>
                {error && <p>{error}</p>}
                <label>
                    Sélectionner une Ressource:
                    <select
                        value={selectedResourceReference}
                        onChange={(e) => setSelectedResourceReference(e.target.value)}
                        required
                    >
                        <option value="">Choisir une ressource</option>
                        {resources.map((resource) => (
                            <option key={resource.reference} value={resource.reference}>
                                {resource.reference} - {resource.description}
                            </option>
                        ))}
                    </select>
                </label>
                <button onClick={handleDelete}>Supprimer</button>
                <button className="cancel-btn" onClick={onClose}>Annuler</button>
            </div>
        </div>
    );
};

SupprimerRess.propTypes = {
    onClose: PropTypes.func.isRequired,
};

export default SupprimerRess;
