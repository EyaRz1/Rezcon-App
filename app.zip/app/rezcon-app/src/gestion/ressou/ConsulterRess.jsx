import { useEffect, useState } from 'react';
import axios from 'axios';
import PropTypes from 'prop-types';

const ConsulterRess = ({ onClose }) => {
    const [resources, setResources] = useState([]);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchResources = async () => {
            try {
                const response = await axios.get('/api/ressources');
                setResources(response.data);
            } catch (error) {
                setError('Erreur lors de la récupération des ressources');
            }
        };

        fetchResources();
    }, []);

    return (
        <div className="modal-overlay">
            <div className="modal-content">
                <button className="close-btn" onClick={onClose}>X</button>
                <h2>Liste des Ressources</h2>
                {error && <p>{error}</p>}
                <ul>
                    {resources.length > 0 ? (
                        resources.map((resource, index) => (
                            <li key={index}>{resource.reference} - {resource.description}</li>
                        ))
                    ) : (
                        <p>Aucune ressource trouvée</p>
                    )}
                </ul>
                <button className="cancel-btn" onClick={onClose}>Annuler</button>
            </div>
        </div>
    );
};

ConsulterRess.propTypes = {
    onClose: PropTypes.func.isRequired,
};

export default ConsulterRess;
