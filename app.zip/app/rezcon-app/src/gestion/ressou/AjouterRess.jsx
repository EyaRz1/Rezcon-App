import { useState } from 'react';
import PropTypes from 'prop-types';
import axios from 'axios';


const AjouterRess = ({ onClose }) => {
    const [resourceName, setResourceName] = useState('');
    const [error, setError] = useState(null);

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await axios.post('/api/resources', { name: resourceName });
            setResourceName('');
            onClose();
        } catch (error) {
            setError('Erreur lors de l\'ajout de la ressource');
        }
    };

    return (
        <div className="modal-overlay">
            <div className="modal-content">
                <button className="close-btn" onClick={onClose}>X</button>
                <h2>Ajouter une Ressource</h2>
                {error && <p>{error}</p>}
                <form onSubmit={handleSubmit}>
                    <label>
                        Nom de la Ressource:
                        <input
                            type="text"
                            value={resourceName}
                            onChange={(e) => setResourceName(e.target.value)}
                            required
                        />
                    </label>
                    <button type="submit">Ajouter</button>
                </form>
                <button className="cancel-btn" onClick={onClose}>Annuler</button>
            </div>
        </div>
    );
};

AjouterRess.propTypes = {
    onClose: PropTypes.func.isRequired,
};

export default AjouterRess;
