import PropTypes from 'prop-types';
import { useState, useEffect } from 'react';
import "./DemarerSession.css";
import logoA from "./logo-a.png";
import logo2 from "./logo-2.png";

const DemarrerSession = ({ sessionId, onClose }) => {
    const [experts, setExperts] = useState([]);
    const [selectedExperts, setSelectedExperts] = useState([]);
    const [criteria, setCriteria] = useState('');
    const [weight, setWeight] = useState('');
    const [resources, setResources] = useState([]);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchExperts = async () => {
            try {
                const response = await fetch('/api/experts');
                if (!response.ok) {
                    throw new Error('Error fetching experts');
                }
                const data = await response.json();
                setExperts(data);
            } catch (error) {
                console.error(error);
                setError('Error fetching experts');
            }
        };

        const fetchResources = async () => {
            try {
                const response = await fetch('/api/ressources');
                if (!response.ok) {
                    throw new Error('Error fetching resources');
                }
                const data = await response.json();
                setResources(data);
            } catch (error) {
                console.error(error);
                setError('Error fetching resources');
            }
        };

        fetchExperts();
        fetchResources();
    }, []);
    
    const handleExpertChange = (event) => {
        const expertId = event.target.value;
        const expert = experts.find(exp => exp.id === parseInt(expertId, 10));
        if (expert && !selectedExperts.some(e => e.id === expert.id)) {
            setSelectedExperts([...selectedExperts, { id: expert.id, name: `${expert.name} ${expert.lastname}`, index: '' }]);
        }
    };

    const handleIndexChange = (name, value) => {
        setSelectedExperts(prev =>
            prev.map(expert =>
                expert.name === name ? { ...expert, index: value } : expert
            )
        );
    };

    const handleSubmit = async () => {
        if (!criteria || !weight || selectedExperts.length === 0) {
            setError('Please fill in all fields');
            return;
        }

        setError(null); // Clear previous errors before proceeding

        try {
            const expertsToSave = selectedExperts.map(expert => ({
                id: expert.id,
                index: expert.index
            }));

            // Debugging: Log payload before sending
            console.log('Session ID:', sessionId);
            console.log('Experts to save:', expertsToSave);
            console.log('Criteria:', criteria);
            console.log('Weight:', weight);

            // Save the selected experts
            const response = await fetch('/api/save-session-experts', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ sessionId, experts: expertsToSave, criteria, weight }),
            });

            if (!response.ok) {
                throw new Error('Error saving experts');
            }

            console.log('Experts saved successfully');

            // Update session progress after successfully saving experts
            const progressResponse = await fetch(`/api/update-session-progress/${sessionId}`, {
                method: 'PATCH',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ status: 'En cours' }), // Modify this to reflect the actual progress value if needed
            });

            if (!progressResponse.ok) {
                throw new Error('Error updating session progress');
            }

            console.log('Session progress updated successfully');

            // Optionally reset the form after saving
            setSelectedExperts([]);
            setCriteria('');
            setWeight('');
        } catch (error) {
            console.error(error);
            setError('Error saving experts or updating session progress');
        }
    };

    return (
        <div className="container-2">
            <div className="header">
                <img src={logoA} alt="Logo A" className="logo-a" />
                <h2>Admin Interface</h2>
                <div className="header-right">
                    <div className="admin-greeting">
                        <p>Hello, Mr. Administrator</p>
                    </div>
                    <img src={logo2} alt="Logo 2" className="logo-2" />
                </div>
            </div>

            <div className="form2">
                <div className="top-section">
                    <div className="reference-index-section">
                        <h4>Experts &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Reference Index</h4>
                        {selectedExperts.length > 0 ? (
                            <div className="reference-index-list">
                                {selectedExperts.map((expert, index) => (
                                    <div key={index} className="expert-row">
                                        <span>{expert.name}</span>
                                        <input
                                            type="text"
                                            value={expert.index}
                                            onChange={(e) => handleIndexChange(expert.name, e.target.value)}
                                            placeholder="Enter index"
                                        />
                                    </div>
                                ))}
                            </div>
                        ) : (
                            <p>No expert selected</p>
                        )}
                    </div>
                </div>

                <div className="selection-section">
                    <div className="select-expert">
                        <h4>Select an Expert</h4>
                        <select onChange={handleExpertChange}>
                            <option value="">Select an Expert</option>
                            {experts.map(expert => (
                                <option key={expert.id} value={expert.id}>
                                    {expert.name} {expert.lastname}
                                </option>
                            ))}
                        </select>
                    </div>
                    <div className="select-criteria">
                        <h4>Select a Criterion</h4>
                        <select value={criteria} onChange={(e) => setCriteria(e.target.value)}>
                            <option value="">Select a Criterion</option>
                            {resources.map(resource => (
                                <option key={resource.id} value={resource.reference}>
                                    {resource.reference}
                                </option>
                            ))}
                        </select>
                    </div>
                    <div className="select-weight">
                        <h4>Select a Weight</h4>
                        <select value={weight} onChange={(e) => setWeight(Number(e.target.value))}>
                            <option value="">Select a Weight</option>
                            {[1, 2, 3].map(w => (
                                <option key={w} value={w}>{w}</option>
                            ))}
                        </select>
                    </div>
                </div>
            </div>
            <div className="actions-buttons-2">
                <button onClick={handleSubmit}>Calculate index and save</button>
                <button onClick={onClose}>Cancel</button>
            </div>
            {error && <p className="error-message">{error}</p>}
        </div>
    );
};

DemarrerSession.propTypes = {
    sessionId: PropTypes.number.isRequired,
    onClose: PropTypes.func.isRequired,
};

export default DemarrerSession;
