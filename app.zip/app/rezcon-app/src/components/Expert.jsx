import './Expert.css';
import PropTypes from 'prop-types';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const Expert = () => {
  const navigate = useNavigate();
  const [name, setName] = useState('');
  const [lastname, setlastname] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
 

  const handleNext = () => {
    if (!name || !lastname || !email || !phone ) {
      alert('All fields must be filled out');
      return;
    }

    const expertInfo = {
      name,
      lastname,
      email,
      phone,
    
      role: 'expert', 
    };

    
    navigate('/expertsuiv', { state: expertInfo });
  };

  return (
    <div className="expert-container">
      <div className="expert-box">
        <h2>Créer un compte expert</h2>
        <div className="expert-form">
          <div className="form-group">
            <label htmlFor="name">Nom</label>
            <input
              type="text"
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>
          <div className="form-group">
            <label htmlFor="lastname">Prénom</label>
            <input
              type="text"
              id="lastname"
              value={lastname}
              onChange={(e) => setlastname(e.target.value)}
            />
          </div>
          <div className="form-group">
            <label htmlFor="email">Email</label>
            <input
              type="email"
              id="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>
          <div className="form-group">
            <label htmlFor="phone">Téléphone</label>
            <input
              type="tel"
              id="phone"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
            />
          </div>
          
          <button className="next-btn" onClick={handleNext}>
            Suivant
          </button>
        </div>
      </div>
    </div>
  );
};

Expert.propTypes = {
  onNext: PropTypes.func.isRequired,
};

export default Expert;
