import { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import ConsulterUsers from './ConsulterUsers';
import SupprimerUser from './SupprimerUser';
import axios from 'axios';
import './GestionUsers.css';

const GestionUsers = ({ onClose }) => {
    const [showConsulterUsers, setShowConsulterUsers] = useState(false);
    const [showSupprimerUser, setShowSupprimerUser] = useState(false);
    const [users, setUsers] = useState([]);

    useEffect(() => {
        const fetchUsers = async () => {
            try {
                const response = await axios.get('/api/users');
                setUsers(response.data);
            } catch (error) {
                console.error('Error fetching users:', error);
            }
        };

        fetchUsers();
    }, []);

    return (
        <div className="gestion-users-overlay">
            <div className="gestion-users-container">
                <div className="gestion-users-header">
                    <h2>Gestion des Utilisateurs</h2>
                    <button className="close-button" onClick={onClose}>&times;</button>
                </div>
                <div className="gestion-users-content">
                    <ul>
                        <li>
                            <button
                                className="action-button"
                                onClick={() => setShowConsulterUsers(true)}
                            >
                                Consulter les utilisateurs
                            </button>
                        </li>
                        <li>
                            <button
                                className="action-button"
                                onClick={() => setShowSupprimerUser(true)}
                            >
                                Supprimer un utilisateur
                            </button>
                        </li>
                    </ul>
                </div>
                <div className="gestion-users-footer">
                    <button className="cancel-button" onClick={onClose}>Annuler</button>
                </div>
                {showConsulterUsers && (
                    <ConsulterUsers 
                        onClose={() => setShowConsulterUsers(false)} 
                        users={users} 
                    />
                )}
                {showSupprimerUser && (
                    <SupprimerUser 
                        onClose={() => setShowSupprimerUser(false)} 
                        users={users} 
                    />
                )}
            </div>
        </div>
    );
};

GestionUsers.propTypes = {
    onClose: PropTypes.func.isRequired,
};

export default GestionUsers;
