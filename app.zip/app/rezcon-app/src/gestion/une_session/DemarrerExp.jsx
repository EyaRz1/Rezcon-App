import PropTypes from 'prop-types';
import { useEffect, useState } from 'react';
import "./DemarerSession.css";
import logoA from "./logo-a.png";
import logo2 from "./logo-2.png";

const DemarrerExp = ({ onClose }) => {
   // State for fetched criteria
    const [subCriteria, setSubCriteria] = useState([]); // State for competencies fetched from Neo4j
   // State for selected criteria
    const [selectedSubCriteria, setSelectedSubCriteria] = useState(''); // State for selected sub-criteria
    const [weight, setWeight] = useState(''); // State for weight

    useEffect(() => {
        // Fetch criteria from the session_expert table
     

        // Fetch competencies from Neo4j
        const fetchCompetencies = async () => {
            const response = await fetch('/api/competences'); // Endpoint to get competencies
            const data = await response.json();
            setSubCriteria(data); // Set competencies from the response
        };

        
        fetchCompetencies();
    }, []);

    

    const handleSubCriteriaChange = (event) => {
        setSelectedSubCriteria(event.target.value); // Update selected sub-criteria
    };

    const handleWeightChange = (event) => {
        setWeight(event.target.value); // Update weight selection
    };

    const handleSubmit = () => {
        // Implement the logic to use selectedCriteria, selectedSubCriteria, and weight
    
        console.log('Selected Sub-Criteria:', selectedSubCriteria);
        console.log('Selected Weight:', weight);

        // Add logic to send the selected criteria, sub-criteria, and weight to your backend
        fetch('/api/save-expert-data', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
          
        })
        .then(response => {
            if (!response.ok) throw new Error('Network response was not ok');
            return response.json();
        })
        .then(data => {
            console.log('Data saved successfully:', data);
            onClose(); // Close the modal or perform other actions
        })
        .catch((error) => {
            console.error('Error saving data:', error);
        });
    };

    return (
        <div className="container-2">
            <div className="header">
                <img src={logoA} alt="Logo A" className="logo-a" />
                <h2>Interface Expert</h2>
                <div className="header-right">
                    <div className="admin-greeting">
                        <p>Bonjour, M. Expert</p>
                    </div>
                    <img src={logo2} alt="Logo 2" className="logo-2" />
                </div>
            </div>

            <div className="form2">
                <div className="selection-section">
                    <div className="select-expert">
                        <h4>Le Critère</h4>
                        
                    </div>
                    <div className="select-criteria">
                        <h4>Sélectionner un Sous-Critère</h4>
                        <select onChange={handleSubCriteriaChange}>
                            <option value="">Sélectionner un sous-critère</option>
                            {/* Render options based on fetched competencies */}
                            {subCriteria && subCriteria.map((competence, index) => (
                                <option key={index} value={competence}>{competence}</option>
                            ))}
                        </select>
                    </div>
                    <div className="select-weight">
                        <h4>Sélectionner une Pondération</h4>
                        <select onChange={handleWeightChange}>
                            <option value="">Sélectionner une pondération</option>
                            <option value="very low">Very Low</option>
                            <option value="low">Low</option>
                            <option value="high">High</option>
                            <option value="very high">Very High</option>
                        </select>
                    </div>
                </div>
            </div>
            <div className="actions-buttons-2">
                <button onClick={handleSubmit}>Enregistrer</button>
                <button onClick={onClose}>Fermer</button>
            </div>
        </div>
    );
};

DemarrerExp.propTypes = {
    onClose: PropTypes.func.isRequired,
};

export default DemarrerExp;
