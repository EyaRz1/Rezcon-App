import './Moderateur.css';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

function Moderateur() {
  const navigate = useNavigate();
  const [name, setName] = useState('');
  const [lastname, setlastname] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [errors, setErrors] = useState({});

  const validateForm = () => {
    const errors = {};
    if (!name) errors.name = "Le nom est requis";
    if (!lastname) errors.lastname = "Le prénom est requis";
    if (!email) errors.email = "L'email est requis";
    if (!phone) errors.phone = "Le téléphone est requis";
    
    return errors;
  };

  const handleNextClick = () => {
    const errors = validateForm();
    setErrors(errors);

    if (Object.keys(errors).length === 0) {
      navigate('/moderateursuiv', { state: { name, lastname, email, phone, role: 'moderateur' } });
    }
  };

  return (
    <div className="moderateur-container">
      <div className="moderateur-box">
        <h2>Rejoignez-nous comme modérateur!</h2>
        <div className="content">
          <div className="moderateur-form">
            <div className="form-row">
              <div className="form-group">
                <label htmlFor="nom">Nom</label>
                <input 
                  type="text" 
                  id="nom" 
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                />
                {errors.name && <p className="error">{errors.name}</p>}
              </div>
              <div className="form-group">
                <label htmlFor="prenom">Prénom</label>
                <input 
                  type="text" 
                  id="prenom" 
                  value={lastname}
                  onChange={(e) => setlastname(e.target.value)}
                  required
                />
                {errors.lastname && <p className="error">{errors.lastname}</p>}
              </div>
            </div>
            <div className="form-group">
              <label htmlFor="email">Email</label>
              <input 
                type="email" 
                id="email" 
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
              {errors.email && <p className="error">{errors.email}</p>}
            </div>
            <div className="form-group">
              <label htmlFor="tel">Téléphone</label>
              <input 
                type="tel" 
                id="tel" 
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
              />
              {errors.phone && <p className="error">{errors.phone}</p>}
            </div>
            <button className="suivant-btn" onClick={handleNextClick}>Suivant</button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Moderateur;
