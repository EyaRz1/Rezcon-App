const mysql = require('mysql2/promise');

const dbConfig = {
  host: 'localhost',
  user: 'root',
  password: '123456789',
  database: 'rezcon',
};



async function createUser(email, password, role, name, lastname, phone) {
  const connection = await mysql.createConnection(dbConfig);

  try {
    const [result] = await connection.execute(
      'INSERT INTO users (email, password, role, name, lastname, phone) VALUES (?, ?, ?, ?, ?, ?)',
      [email, password, role, name, lastname, phone]
    );
    return { id: result.insertId, email, role, name, lastname, phone };
  } catch (error) {
    console.error('Error creating user:', error);
    throw error;
  } finally {
    await connection.end();
  }
}

async function findUserByEmail(email) {
  const connection = await mysql.createConnection(dbConfig);

  try {
    const [rows] = await connection.execute(
      'SELECT * FROM users WHERE email = ?',
      [email]
    );

    if (rows.length === 0) return null;
    return rows[0];
  } catch (error) {
    console.error('Error finding user:', error);
    throw error;
  } finally {
    await connection.end();
  }
}



async function getAllUsers() {
  const connection = await mysql.createConnection(dbConfig);

  try {
    const [rows] = await connection.execute('SELECT * FROM users');
    return rows;
  } catch (error) {
    console.error('Error fetching users:', error);
    throw error;
  } finally {
    await connection.end();
  }
}

async function deleteUser(id) {
  const connection = await mysql.createConnection(dbConfig);

  try {
    const [result] = await connection.execute(
      'DELETE FROM users WHERE id = ?',
      [id]
    );
    
    if (result.affectedRows === 0) {
      throw new Error('User not found.');
    }
    
    return result;
  } catch (error) {
    console.error('Error deleting user:', error);
    throw error;
  } finally {
    await connection.end();
  }
}


async function addSession(description, nom, start, end, moderator, status) {
  const connection = await mysql.createConnection(dbConfig);

  try {
    const [result] = await connection.execute(
      'INSERT INTO sessions (description, nom, start, end, moderator, status) VALUES (?, ?, ?, ?, ?, ?)',
      [description, nom, start, end, moderator, status]
    );
    return { id: result.insertId, description, nom, start, end, moderator, status };
  } catch (error) {
    console.error('Error adding session:', error);
    throw error;
  } finally {
    await connection.end();
  }
}


async function getModerators() {
  const connection = await mysql.createConnection(dbConfig);

  try {
    const [rows] = await connection.execute(
      'SELECT id, name, lastname FROM users WHERE role = ?',
      ['moderateur']
    );
    return rows;
  } catch (error) {
    console.error('Error fetching moderators:', error);
    throw error;
  } finally {
    await connection.end();
  }
}


async function getAllSessions(moderator_id) {
  const connection = await mysql.createConnection(dbConfig);

  try {
    let query = 'SELECT * FROM sessions';
    const params = [];

    if (moderator_id) {
      query += ' WHERE moderator = ?';
      params.push(moderator_id);
    }

    const [rows] = await connection.query(query, params);
    return rows;
  } catch (error) {
    console.error('Error fetching sessions:', error);
    throw error;
  } finally {
    await connection.end();
  }
}



async function updateSession(id, description, nom, start, end, moderator, status) {
  const connection = await mysql.createConnection(dbConfig);

  try {
    const [result] = await connection.execute(
      'UPDATE sessions SET description = ?, nom = ?, start = ?, end = ?, moderator = ?, status = ? WHERE id = ?',
      [description, nom, start, end, moderator, status, id]
    );
    
    if (result.affectedRows === 0) {
      throw new Error('Session not found or no changes made.');
    }
    
    return result;
  } catch (error) {
    console.error('Error updating session:', error);
    throw error;
  } finally {
    await connection.end();
  }
}


async function deleteSession(id) {
  const connection = await mysql.createConnection(dbConfig);

  try {
    const [result] = await connection.execute(
      'DELETE FROM sessions WHERE id = ?',
      [id]
    );
    
    if (result.affectedRows === 0) {
      throw new Error('Session not found.');
    }
    
    return result;
  } catch (error) {
    console.error('Error deleting session:', error);
    throw error;
  } finally {
    await connection.end();
  }
}
async function getExperts() {
  const connection = await mysql.createConnection(dbConfig);

  try {
    const [rows] = await connection.execute(
      'SELECT id, name, lastname FROM users WHERE role = ?',
      ['expert']
    );
    return rows;
  } catch (error) {
    console.error('Error fetching experts:', error.message);
    console.error('SQL Query:', 'SELECT id, name, lastname FROM users WHERE role = ?', ['expert']);
    throw error;
  } finally {
    await connection.end();
  }
}



module.exports = {
  createUser,
  findUserByEmail,
  addSession,
  getModerators,
  getAllSessions,
  updateSession,
  deleteSession, 
  getAllUsers,   
  deleteUser,
  getExperts,  
};
