import { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import './ModerateurDashboard.css';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import ConsulterSess from '../gestion/ConsulterSess';
import ConnecterSess from '../gestion/ModerateurG/ConnecterSess';
import DemarrerSession from '../gestion/une_session/DemarrerMod';
import AjouterComp from '../gestion/comp/AjouterComp';
import SupprimerComp from '../gestion/comp/supprimerComp';
import ConsulterComp from '../gestion/comp/ConsulterComp';
import AjouterRess from '../gestion/ressou/AjouterRess';
import SupprimerRess from '../gestion/ressou/SupprimerRess';
import ConsulterRess from '../gestion/ressou/ConsulterRess';

// Import your logo images
import logoA from './logo-a.png';
import logo2 from './logo-2.png';

const ModerateurDashboard = ({ user, logoutUser }) => {
    const [showConsulterSess, setShowConsulterSess] = useState(false);
    const [showConnecterSess, setShowConnecterSess] = useState(false);
    const [showDemarrerSession, setShowDemarrerSession] = useState(false);
    const [showCompetencyOptions, setShowCompetencyOptions] = useState(false);
    const [showCompetencyModal, setShowCompetencyModal] = useState('');
    const [showResourceOptions, setShowResourceOptions] = useState(false);
    const [showResourceModal, setShowResourceModal] = useState('');
    const [sessions, setSessions] = useState([]);
    const [selectedSession, setSelectedSession] = useState(null);

    const navigate = useNavigate();

    useEffect(() => {
        const fetchSessions = async () => {
            try {
                const response = await axios.get('/api/sessions');
                setSessions(response.data);
            } catch (error) {
                console.error('Failed to fetch sessions', error);
            }
        };

        fetchSessions();
    }, []);

    const handleLogout = () => {
        logoutUser();
        navigate('/');
    };

    const handleSelectSession = (session) => {
        if (session.moderator === user.id) {
            setSelectedSession(session);
            setShowDemarrerSession(true);
        } else {
            alert("Vous n'êtes pas autorisé à démarrer cette session.");
        }
        setShowConsulterSess(false);
        setShowConnecterSess(false);
    };

    const handleCloseModals = () => {
        setShowConsulterSess(false);
        setShowConnecterSess(false);
        setShowDemarrerSession(false);
        setSelectedSession(null);
        setShowCompetencyModal('');
        setShowResourceModal('');
        setShowCompetencyOptions(false);
        setShowResourceOptions(false);
    };

    const openCompetencyModal = (type) => setShowCompetencyModal(type);
    const closeCompetencyModal = () => setShowCompetencyModal('');

    const openResourceModal = (type) => setShowResourceModal(type);
    const closeResourceModal = () => setShowResourceModal('');

    const toggleCompetencyOptions = () => setShowCompetencyOptions(!showCompetencyOptions);
    const toggleResourceOptions = () => setShowResourceOptions(!showResourceOptions);

    if (!user || !user.name || !user.lastname) {
        return <div>Loading...</div>;
    }

    return (
        <div className="dashboard">
            <aside className="sidebar">
                <div className="sidebar-header">
                    <h2>Dashboard</h2>
                </div>
                <nav className="sidebar-nav">
                    <ul>
                        <li onClick={toggleResourceOptions}>
                            Gérer ressources
                            {showResourceOptions && (
                                <ul className="sub-menu">
                                    <li onClick={() => openResourceModal('ajouter')}>Ajouter ressource</li>
                                    <li onClick={() => openResourceModal('supprimer')}>Supprimer ressource</li>
                                    <li onClick={() => openResourceModal('consulter')}>Consulter les ressources</li>
                                </ul>
                            )}
                        </li>
                        <li onClick={toggleCompetencyOptions}>
                            Gérer compétences
                            {showCompetencyOptions && (
                                <ul className="sub-menu">
                                    <li onClick={() => openCompetencyModal('ajouter')}>Ajouter compétence</li>
                                    <li onClick={() => openCompetencyModal('supprimer')}>Supprimer compétence</li>
                                    <li onClick={() => openCompetencyModal('consulter')}>Consulter les compétences</li>
                                </ul>
                            )}
                        </li>
                        <li>Suivi des évaluations</li>
                        <li>Notifications de conflit</li>
                    </ul>
                </nav>
                <button className="logout-btn" onClick={handleLogout}>Se déconnecter</button>
            </aside>
            <div className="main-content">
                <header className="dashboard-header">
                    <div className="user-info">
                        {/* Add Logo A before the user's greeting */}
                        <img src={logoA} alt="Logo A" className="logo-a" /> 
                        Modérateur {user.name} {user.lastname}
                        {/* Add Logo 2 on the extreme right */}
                        <img src={logo2} alt="Logo 2" className="logo-2" style={{ float: 'right' }} />
                    </div>
                </header>
                <div className="dashboard-content">
                    <div className="dashboard-section">
                        <h2>Sessions en cours</h2>
                        <table className="dashboard-table">
                            <thead>
                                <tr>
                                    <th>Nom de la Session</th>
                                    <th>Date Début</th>
                                    <th>Date Fin</th>
                                    <th>Modérateur</th>
                                    <th>Description</th>
                                    <th>Progression</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                {sessions.length === 0 ? (
                                    <tr>
                                        <td colSpan="7">Aucune session trouvée.</td>
                                    </tr>
                                ) : (
                                    sessions.map((session) => (
                                        <tr key={session.id}>
                                            <td>{session.nom}</td>
                                            <td>{new Date(session.start).toLocaleDateString()}</td>
                                            <td>{new Date(session.end).toLocaleDateString()}</td>
                                            <td>{session.moderator}</td>
                                            <td>{session.description}</td>
                                            <td>{session.status}</td>
                                            <td>
    {session.status === 'Terminé' ? (
        'Session terminée'
    ) : session.status === 'En cours' ? ( // Ajoutez cette condition
        'Session en cours' // Afficher un message ou autre si la session est en cours
    ) : (
        <button onClick={() => handleSelectSession(session)}>
            Démarrer
        </button>
    )}
</td>

                                        </tr>
                                    ))
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            {showConsulterSess && <ConsulterSess sessions={sessions} onClose={handleCloseModals} />}
            {showConnecterSess && <ConnecterSess onClose={handleCloseModals} userId={user.id} />}
            {showDemarrerSession && selectedSession && (
                <div className="modal-overlay">
                    <DemarrerSession session={selectedSession} onClose={handleCloseModals} />
                </div>
            )}
            {showCompetencyModal === 'ajouter' && (
                <div className="modal-overlay">
                    <AjouterComp onClose={closeCompetencyModal} />
                </div>
            )}
            {showCompetencyModal === 'supprimer' && (
                <div className="modal-overlay">
                    <SupprimerComp onClose={closeCompetencyModal} />
                </div>
            )}
            {showCompetencyModal === 'consulter' && (
                <div className="modal-overlay">
                    <ConsulterComp onClose={closeCompetencyModal} />
                </div>
            )}
            {showResourceModal === 'ajouter' && (
                <div className="modal-overlay">
                    <AjouterRess onClose={closeResourceModal} />
                </div>
            )}
            {showResourceModal === 'supprimer' && (
                <div className="modal-overlay">
                    <SupprimerRess onClose={closeResourceModal} />
                </div>
            )}
            {showResourceModal === 'consulter' && (
                <div className="modal-overlay">
                    <ConsulterRess onClose={closeResourceModal} />
                </div>
            )}
        </div>
    );
};

ModerateurDashboard.propTypes = {
    user: PropTypes.shape({
        name: PropTypes.string.isRequired,
        lastname: PropTypes.string.isRequired,
        id: PropTypes.number.isRequired,
    }).isRequired,
    logoutUser: PropTypes.func.isRequired,
};

export default ModerateurDashboard;
