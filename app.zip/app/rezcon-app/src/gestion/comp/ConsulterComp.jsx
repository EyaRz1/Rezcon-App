import { useEffect, useState } from 'react';
import axios from 'axios';
import PropTypes from 'prop-types';
import './ConsulterComp.css'; 

const ConsulterComp = ({ onClose }) => {
    const [competences, setCompetences] = useState([]);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchCompetences = async () => {
            try {
                const response = await axios.get('/api/competences');
                setCompetences(response.data);
            } catch (error) {
                setError('Erreur lors de la récupération des compétences');
            }
        };

        fetchCompetences();
    }, []);

    return (
        <div className="modal-overlay">
            <div className="modal-content">
                <button className="close-btn" onClick={onClose}>Close</button>
                <h2>Liste des Compétences</h2>
                {error && <p>{error}</p>}
                <ul>
                    {competences.length > 0 ? (
                        competences.map((competence, index) => (
                            <li key={index}>{competence}</li>
                        ))
                    ) : (
                        <p>Aucune compétence trouvée</p>
                    )}
                </ul>
                <button className="cancel-btn" onClick={onClose}>Cancel</button>
            </div>
        </div>
    );
};

ConsulterComp.propTypes = {
    onClose: PropTypes.func.isRequired,
};

export default ConsulterComp;
