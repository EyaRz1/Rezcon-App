import { useState } from 'react';
import PropTypes from 'prop-types';
import axios from 'axios';
import './SupprimerSess.css'; 

function SupprimerSess({ onClose }) {
  const [sessionId, setSessionId] = useState('');
  const [message, setMessage] = useState('');

  const handleDelete = async () => {
    try {
      await axios.delete(`/api/sessions/${sessionId}`);
      setMessage('Session deleted successfully');
    } catch (error) {
      console.error('Error deleting session:', error);
      setMessage('Error deleting session');
    }
  };

  return (
    <div className="supprimer-sess-overlay">
      <div className="supprimer-sess-container">
        <div className="supprimer-sess-header">
          <h1>Supprimer Session</h1>
          <button className="close-button" onClick={onClose}>&times;</button>
        </div>
        <input
          type="text"
          value={sessionId}
          onChange={(e) => setSessionId(e.target.value)}
          placeholder="Enter session ID"
        />
        <button type="button" onClick={handleDelete}>
          Delete Session
        </button>
        <button type="button" className="cancel-button" onClick={onClose}>
          Annuler
        </button>
        {message && <p>{message}</p>}
      </div>
    </div>
  );
}


SupprimerSess.propTypes = {
  onClose: PropTypes.func.isRequired, 
};

export default SupprimerSess;
