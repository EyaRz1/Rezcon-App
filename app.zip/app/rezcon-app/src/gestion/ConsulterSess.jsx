import { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import axios from 'axios';
import './ConsulterSess.css';

function ConsulterSess({ onClose }) {
  const [sessions, setSessions] = useState([]);

  useEffect(() => {
    const fetchSessions = async () => {
      try {
        const response = await axios.get('/api/sessions');
        setSessions(response.data);
      } catch (error) {
        console.error('Error fetching sessions:', error);
      }
    };

    fetchSessions();
  }, []);

  return (
    <div className="consulter-sess-overlay">
      <div className="consulter-sess-container">
        <div className="consulter-sess-header">
          <h1>Consulter Sessions</h1>
          <button className="close-button-cons" onClick={onClose}>&times;</button>
        </div>
        <div className="consulter-sess-content">
          <ul>
            {sessions.map(session => (
              <li key={session.id} className="session-item">
                <p><strong>ID:</strong> {session.id}</p>
                <p><strong>Nom:</strong> {session.nom}</p>
                <p><strong>Description:</strong> {session.description}</p>
                <p><strong>Démarrage:</strong> {new Date(session.start).toLocaleDateString()}</p>
                <p><strong>Fin:</strong> {new Date(session.end).toLocaleDateString()}</p>
                <p><strong>Modérateur:</strong> {session.moderator}</p>
                <p><strong>Status:</strong> {session.status}</p>
              </li>
            ))}
          </ul>
        </div>
        <div className="consulter-sess-footer">
          <button className="cancel-button-cons" onClick={onClose}>Fermer</button>
        </div>
      </div>
    </div>
  );
}

ConsulterSess.propTypes = {
  onClose: PropTypes.func.isRequired,
};

export default ConsulterSess;
