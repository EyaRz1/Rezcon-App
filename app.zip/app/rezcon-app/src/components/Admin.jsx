import './Admin.css';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

function Admin() {
  const navigate = useNavigate();
  const [name, setName] = useState('');
  const [lastname, setLastname] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');

  const handleNextClick = () => {
    if (  !lastname || !email || !phone) {
      alert('All fields must be filled out');
      return;
    }

    navigate('/adminsuiv', { state: { name, lastname, email, phone, role: 'admin' } });
  };

  return (
    <div className="admin-container">
      <div className="admin-box">
        <button className="close-btn">x</button>
        <h2>Rejoignez-nous et optimisez vos évaluations!</h2>
        <div className="content">
          <div className="admin-form">
            <div className="form-row">
              <div className="form-group">
                <input
                  type="text"
                  id="nom"
                  placeholder="Nom"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                />
              </div>
              <div className="form-group">
                <input
                  type="text"
                  id="prenom"
                  placeholder="Prenom"
                  value={lastname}
                  onChange={(e) => setLastname(e.target.value)}
                />
              </div>
            </div>
            <div className="form-group">
              <input
                type="email"
                id="email"
                placeholder="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
            <div className="form-group">
              <input
                type="tel"
                id="tel"
                placeholder="Telephone"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
              />
            </div>
            
            <button className="suivant-btn" onClick={handleNextClick}>suivant</button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Admin;
