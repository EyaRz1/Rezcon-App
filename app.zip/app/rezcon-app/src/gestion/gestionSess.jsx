import { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import AjouterSession from './AjouterSession';
import EditerSession from './EditerSession';
import ConsulterSess from './ConsulterSess'; 
import SupprimerSess from './SupprimerSess'; 
import axios from 'axios';
import './GestionSess.css';

const GestionSess = ({ onClose }) => {
    const [showAddSession, setShowAddSession] = useState(false);
    const [showEditSession, setShowEditSession] = useState(false);
    const [showConsulterSess, setShowConsulterSess] = useState(false); 
    const [showSupprimerSess, setShowSupprimerSess] = useState(false); 
    const [sessions, setSessions] = useState([]);

    useEffect(() => {
        const fetchSessions = async () => {
            try {
                const response = await axios.get('/api/sessions');
                setSessions(response.data);
            } catch (error) {
                console.error('Error fetching sessions:', error);
            }
        };

        fetchSessions();
    }, []);

    return (
        <div className="gestion-sess-overlay">
            <div className="gestion-sess-container">
                <div className="gestion-sess-header">
                    <h2>Gestion des Sessions</h2>
                    <button className="close-button" onClick={onClose}>&times;</button>
                </div>
                <div className="gestion-sess-content">
                    <ul>
                        <li>
                            <button
                                className="save-button"
                                onClick={() => setShowAddSession(true)}
                            >
                                Ajouter une session
                            </button>
                        </li>
                        <li>
                            <button
                                className="save-button"
                                onClick={() => setShowEditSession(true)}
                            >
                                Éditer une session
                            </button>
                        </li>
                        <li>
                            <button
                                className="save-button"
                                onClick={() => setShowConsulterSess(true)}
                            >
                                Consulter les sessions
                            </button>
                        </li>
                        <li>
                            <button
                                className="save-button"
                                onClick={() => setShowSupprimerSess(true)}
                            >
                                Supprimer une session
                            </button>
                        </li>
                    </ul>
                </div>
                <div className="gestion-sess-footer">
                    <button className="cancel-button" onClick={onClose}>Annuler</button>
                </div>
                {showAddSession && <AjouterSession onClose={() => setShowAddSession(false)} />}
                {showEditSession && (
                    <EditerSession
                        onClose={() => setShowEditSession(false)}
                        sessions={sessions} 
                    />
                )}
                {showConsulterSess && (
                    <ConsulterSess onClose={() => setShowConsulterSess(false)} /> 
                )}
                {showSupprimerSess && (
                    <SupprimerSess onClose={() => setShowSupprimerSess(false)} /> 
                )}
            </div>
        </div>
    );
};

GestionSess.propTypes = {
    onClose: PropTypes.func.isRequired,
};

export default GestionSess;
