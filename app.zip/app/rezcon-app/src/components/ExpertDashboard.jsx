import { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import './ExpertDashboard.css';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import ConsulterSess from '../gestion/ConsulterSess';
import ConnecterSess from '../gestion/ModerateurG/ConnecterSess';
import DemarrerSession from '../gestion/une_session/DemarrerExp';

// Import your logo images
import logoA from './logo-a.png';
import logo2 from './logo-2.png';

const ExpertDashboard = ({ user, logoutUser }) => {
    const [showConsulterSess, setShowConsulterSess] = useState(false);
    const [showConnecterSess, setShowConnecterSess] = useState(false);
    const [showDemarrerSession, setShowDemarrerSession] = useState(false);
    const [sessions, setSessions] = useState([]);
    const [selectedSession, setSelectedSession] = useState(null);

    const navigate = useNavigate();

    useEffect(() => {
        const fetchSessions = async () => {
            try {
                // Récupérer les sessions associées à l'expert
                const response = await axios.get(`/api/sessions?expert_id=${user.id}`);
                setSessions(response.data);
            } catch (error) {
                console.error('Failed to fetch sessions', error);
            }
        };

        fetchSessions();
    }, [user.id]); // Dépendance ajoutée à l'ID de l'utilisateur

    const handleLogout = () => {
        logoutUser();
        navigate('/');
    };

    const handleCloseModals = () => {
        setShowConsulterSess(false);
        setShowConnecterSess(false);
        setShowDemarrerSession(false);
        setSelectedSession(null);
    };

    if (!user || !user.name || !user.lastname) {
        return <div>Loading...</div>;
    }

    return (
        <div className="dashboard">
            <aside className="sidebar">
                <div className="sidebar-header">
                    <h2>Dashboard</h2>
                </div>
                <nav className="sidebar-nav">
                    <ul>
                        <li>Suivi des évaluations</li>
                        <li>Notifications de conflit</li>
                    </ul>
                </nav>
                <button className="logout-btn" onClick={handleLogout}>Se déconnecter</button>
            </aside>
            <div className="main-content">
                <header className="dashboard-header">
                    <div className="user-info">
                        {/* Add Logo A before the user's greeting */}
                        <img src={logoA} alt="Logo A" className="logo-a" />
                        Expert {user.name} {user.lastname}
                        {/* Add Logo 2 on the extreme right */}
                        <img src={logo2} alt="Logo 2" className="logo-2" style={{ float: 'right' }} />
                    </div>
                </header>
                <div className="dashboard-content">
                    <div className="dashboard-section">
                        <h2>Sessions en cours</h2>
                        <table className="dashboard-table">
                            <thead>
                                <tr>
                                    <th>Nom de la Session</th>
                                    <th>Date Début</th>
                                    <th>Date Fin</th>
                                    <th>Modérateur</th>
                                    <th>Description</th>
                                    <th>Progression</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                {sessions.length === 0 ? (
                                    <tr>
                                        <td colSpan="7">Aucune session trouvée.</td>
                                    </tr>
                                ) : (
                                    sessions.map((session) => (
                                        <tr key={session.id}>
                                            <td>{session.nom}</td>
                                            <td>{new Date(session.start).toLocaleDateString()}</td>
                                            <td>{new Date(session.end).toLocaleDateString()}</td>
                                            <td>{session.moderator}</td>
                                            <td>{session.description}</td>
                                            <td>{session.status}</td>
                                            <td>
                                                {session.status === 'Terminé' ? (
                                                    'Session terminée'
                                                ) : session.status === 'En cours' ? (
                                                    <button onClick={() => {
                                                        setSelectedSession(session);
                                                        setShowDemarrerSession(true);
                                                    }}>
                                                        Démarrer
                                                    </button>
                                                ) : (
                                                    'Non disponible'
                                                )}
                                            </td>
                                        </tr>
                                    ))
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            {showConsulterSess && <ConsulterSess sessions={sessions} onClose={handleCloseModals} />}
            {showConnecterSess && <ConnecterSess onClose={handleCloseModals} userId={user.id} />}
            {showDemarrerSession && selectedSession && (
                <div className="modal-overlay">
                    <DemarrerSession session={selectedSession} onClose={handleCloseModals} />
                </div>
            )}
        </div>
    );
};

ExpertDashboard.propTypes = {
    user: PropTypes.shape({
        name: PropTypes.string.isRequired,
        lastname: PropTypes.string.isRequired,
        id: PropTypes.number.isRequired,
    }).isRequired,
    logoutUser: PropTypes.func.isRequired,
};

export default ExpertDashboard;
